
public class Defaultconstructor {
	int id;
	Convertion name;
	
	void display()
	{
		System.out.println(id+" "+name);
	}
}
