
public class constructormainmethod1 {
	public static void main(String[] args) {
		student std1 = new student(1,"Ramu");
		student std2 = new student(2,"Rahul");
		std1.display();
		std2.display();		
	}

}
