
public class Constructormainmethod 
{
	public static void main(String[] args) {
		Defaultconstructor obj1 = new Defaultconstructor();
		Defaultconstructor obj2 = new Defaultconstructor();
		obj1.display();
		obj2.display();
	}
}
