
public class student {
int id;
String name;
student(int i,String n){
	id=i;
	name=n;
}
void display() {
	System.out.println(id+" "+name);
}
}
