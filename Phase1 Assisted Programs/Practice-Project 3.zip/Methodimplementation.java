
public class Methodimplementation 
{
	public int addingnumber(int a, int b) 
	{
		int x=a+b;
		return x;
	}
	public static void main(String[] args) 
	{
		Methodimplementation imp = new Methodimplementation();
		int result;
		result=imp.addingnumber(25, 95);
		System.out.println("Addition of two number using method implementation :"+result);
	}

}
