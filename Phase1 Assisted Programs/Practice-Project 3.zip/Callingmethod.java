
public class Callingmethod 
{
	int val=100;
	int operation(int val) 
	{
		val = val*10/100;
		return val;
	}
	public static void main(String[] args) 
	{
		Callingmethod cm = new Callingmethod();
		System.out.println("Before operation value of data is"+cm.val);
		cm.operation(200);
		System.out.println("After operation value of data is"+cm.val);
	}
}

