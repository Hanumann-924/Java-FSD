
public class FirstThread extends Thread
{
	public void run() {
		System.out.println("Running a program");
	}
	public static void main(String[] args) {
		FirstThread ft = new FirstThread();
		ft.start();
	}
}
