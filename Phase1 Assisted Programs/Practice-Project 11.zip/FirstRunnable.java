
public class FirstRunnable implements Runnable
{
	public static int myCount = 0;
	public FirstRunnable() {
		
	}
	public void run() {
		while(FirstRunnable.myCount<=10) {
			try {
				System.out.println("Expl Thread: "+(++FirstRunnable.myCount));
				Thread.sleep(100);
			}catch(InterruptedException ex) {
				System.out.println("Exception in thread:"+ex.getMessage());
				
			}
		}
	}
	public static void main(String[] args) 
	{
		System.out.println("Staring a thread..");
		FirstRunnable fr = new FirstRunnable();
		Thread t = new Thread(fr);
		t.start();
		while(FirstRunnable.myCount<=10) {
			try {
				System.out.println("Main Thread: "+(++FirstRunnable.myCount));
				Thread.sleep(100);
			}catch(InterruptedException ex) {
				System.out.println("Exception in thread:"+ex.getMessage());
				
			}
		}
		System.out.println("End of the Main Thread");
	}
}
