
public class Typecasting {
	public static void main(String[] args) {
		System.out.println("-------Type Casting------");
		System.out.println("Implicit Typecasting");
		char c = 'H';
		int v = c;
		System.out.println("Value of H in Integer is :"+ v);
		int x = 10; 
		float y = x;
		System.out.println("Value of y is:"+y);
		float z = c;
		System.out.println("Value of z is:"+z);
		long w = c;
		System.out.println("Value of w is :"+ w);
		
		System.out.println("\n");
		
		System.out.println("Explicit Typecasting");
		double a =45.5;
		int b  =  (int)a;
		System.out.println("Value of a: "+a);
		System.out.println("Value of b: "+b);

		
	}

}
